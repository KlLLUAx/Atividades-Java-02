package br.com.fuctura.metodosSql;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import br.com.fuctura.entidades.Aluno;

public class MetodosSql {
public static void adicionarAluno(Connection conn, Aluno aluno) throws SQLException  {
		String sql = "INSERT INTO aluno VALUES(?,?,?,?,?,?);";
		
		PreparedStatement pstm = conn.prepareStatement(sql);
		
		pstm.setString(1, aluno.getNome());
		pstm.setString(2,aluno.getGenero());
		pstm.setString(3,aluno.getCpf());
		pstm.setString(4,aluno.getCelular());
		pstm.setString(5,aluno.getTelefone());
		pstm.setString(6,aluno.getEmail());
		
		pstm.execute();

}
public static void excluirAluno(Connection conn, Aluno aluno) throws SQLException {
	String sql = "DELETE FROM aluno WHERE cpf LIKE (?);";
	
	PreparedStatement pstm = conn.prepareStatement(sql);
	
	pstm.setString(1, aluno.getCpf());
	
	pstm.execute();
	
	
}
public static void excluirTodosAluno(Connection conn,Aluno aluno) throws SQLException {
	String sql = "DELETE FROM aluno;";
	
	PreparedStatement pstm = conn.prepareStatement(sql);
	
	pstm.execute();
}
 public static  ArrayList<Aluno> consultarAlunos(Connection conn,Aluno aluno) throws SQLException {
	String sql = "SELECT * FROM aluno;";
	
	PreparedStatement pstm = conn.prepareStatement(sql);
	
	ResultSet resultadoConsulta = pstm.executeQuery();
	
	ArrayList<Aluno> lista = new ArrayList<>();
	
	while(resultadoConsulta.next()) {
		String nome = resultadoConsulta.getString(1);
		String genero = resultadoConsulta.getString(2);
		String cpf = resultadoConsulta.getString(3);
		String celular = resultadoConsulta.getString(4);
		String telefone = resultadoConsulta.getString(5);
		String email = resultadoConsulta.getString(6);
		
		Aluno a = new Aluno();
		
		a.setNome(nome);
		a.setGenero(genero);
		a.setCpf(cpf);
		a.setCelular(celular);
		a.setTelefone(telefone);
		a.setEmail(email);
		
		
		lista.add(a);
		
	}
			
		resultadoConsulta.close();	
				
			return lista;
}
 public static  ArrayList<Aluno> consultarAlunoCpf(Connection conn, Aluno aluno) throws SQLException {
	 String sql = "SELECT * FROM aluno WHERE cpf LIKE ?;";
	 
	 PreparedStatement pstm = conn.prepareStatement(sql);
	 
	 pstm.setString(1, aluno.getCpf());
	 
	 ResultSet resultadoConsulta = pstm.executeQuery();
	 ArrayList<Aluno> lista = new ArrayList<>();
	 while(resultadoConsulta.next()) {
		 String nome = resultadoConsulta.getString("nome");
		 String genero = resultadoConsulta.getString("genero");
		 String cpf = resultadoConsulta.getString("cpf");
		 String celular = resultadoConsulta.getString("numerocelular");
		 String telefone = resultadoConsulta.getString("telefonefixo");
		 String email = resultadoConsulta.getString("email");
		 Aluno a = new Aluno();
		 
		 a.setNome(nome);
		 a.setGenero(genero);
		 a.setCpf(cpf);
		 a.setCelular(celular);
		 a.setTelefone(telefone);
		 a.setEmail(email);
		 
		lista.add(a);
		 
	 }
	 resultadoConsulta.close();
	
			 return  lista;
 }
 public static void atualizarCelular(Connection conn, Aluno aluno) throws SQLException {
	 String sql = ("UPDATE aluno SET numerocelular = (?) WHERE cpf LIKE ?;");
	 
	 PreparedStatement pstm = conn.prepareStatement(sql);
	 
	 pstm.setString(1, aluno.getCelular());
	 pstm.setString(2, aluno.getCpf());
	 
	 pstm.executeUpdate();
 }
 public static void atualizarTelefone(Connection conn, Aluno aluno) throws SQLException {
	 String sql = ("UPDATE aluno SET telefornefixo = (?) WHERE cpf LIKE ?;");
	 
	 PreparedStatement pstm = conn.prepareStatement(sql);
	 
	 pstm.setString(1, aluno.getTelefone());
	 pstm.setString(2, aluno.getCpf());
	 
	 pstm.executeUpdate();
 
 }
 public static void atualizarEmail(Connection conn, Aluno aluno) throws SQLException {
	 String sql = ("UPDATE aluno SET email = (?) WHERE cpf LIKE ?;");
	 
	 PreparedStatement pstm = conn.prepareStatement(sql);
	 
	 pstm.setString(1, aluno.getEmail());
	 pstm.setString(2, aluno.getCpf());
	 
	 pstm.executeUpdate();
 }
 
}