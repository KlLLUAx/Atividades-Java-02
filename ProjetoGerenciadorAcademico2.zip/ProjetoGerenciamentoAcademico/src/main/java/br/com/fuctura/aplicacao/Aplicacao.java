package br.com.fuctura.aplicacao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Properties;
import java.util.Scanner;

import br.com.fuctura.entidades.Aluno;
import br.com.fuctura.metodosSql.MetodosSql;

public class Aplicacao {

	public static void main(String[] args) throws SQLException {
		
		String url = "jdbc:postgresql://localhost:5432/postgres";
		
		Properties props = new Properties();
		props.setProperty("user", "postgres");
		props.setProperty("password", "123");

		Connection conn = DriverManager.getConnection(url, props);

		Aluno aluno = new Aluno();

		menu(conn,aluno);
	}
	
	public static void menuCadastro(Connection conn ,Aluno aluno ) throws SQLException {
		Scanner s =  new Scanner(System.in);
		System.out.println("Digite o nome do aluno: ");
		String nome = s.nextLine();
		aluno.setNome(nome);
		System.out.println("Digite o genero do aluno: ");
		String genero = s.next();
		aluno.setGenero(genero);
		System.out.println("Digite o cpf do aluno: ");
		String cpf = s.next();
		aluno.setCpf(cpf);
		System.out.println("Digite o numero de celular do aluno: ");
		String celular =s.next();
		aluno.setCelular(celular);
		System.out.println("Digite o telefone fixo do aluno: ");
		String telefone = s.next();
		aluno.getTelefone();
		System.out.println("Digite o email do aluno: ");
		String email = s.next();
		aluno.setEmail(email);
		

		MetodosSql.adicionarAluno(conn, aluno);
	}
	public static void menuExcluir(Connection conn,Aluno aluno) throws SQLException {
		Scanner s =  new Scanner(System.in);
		int opc = 0;
		System.out.println("MENU EXCLUSÃO");
		System.out.println("1 - Excluir todos os alunos");
		System.out.println("2 - Excluir Aluno por CPF");
		opc = s.nextInt();
		if(opc == 1){
			System.err.println("Você está prestes a DELETAR todos os dados da sua tabela!");
			System.out.println("1 - Confirmar");
			System.out.println("2 - Cancelar");
			opc = s.nextInt();
			if(opc == 1) {
				MetodosSql.excluirTodosAluno(conn, aluno);
			}else if(opc == 2) {
				System.out.println("Operação Cancelada!");
			}else {
				System.err.println("Digite uma opção valida");
				menuExcluir(conn,aluno);
			}
		}else if(opc == 2) {
			System.out.println("Digite o cpf do aluno que deseja excluir: ");

			aluno.setCpf(s.next());

			MetodosSql.excluirAluno(conn, aluno);
		}
		
		
	}
	public static void menuConsulta(Connection conn,Aluno aluno) throws SQLException {
		Scanner s =  new Scanner(System.in);
		int opc =0;
		System.out.println("MENU CONSULTA");
		System.out.println("1 - Exibir todos os alunos");
		System.out.println("2 - Consultar Aluno por CPF");
		opc = s.nextInt();
		if (opc == 1) {
			ArrayList<Aluno> lista = MetodosSql.consultarAlunos(conn,aluno);
			for(Aluno a:lista) {
				System.out.println("Nome: "+a.getNome());
				System.out.println("Genero: "+a.getGenero());
				System.out.println("CPF: "+a.getCpf());
			}
		} else if (opc == 2) {
			System.out.println("Digite o CPF do aluno: ");
			String cpf = s.next();
			aluno.setCpf(cpf);
			ArrayList<Aluno> lista = MetodosSql.consultarAlunoCpf(conn, aluno);
			for(Aluno a:lista) {
				System.out.println("Nome: "+a.getNome());
				System.out.println("Genero: "+a.getGenero());
				System.out.println("CPF: "+a.getCpf());
			}
			
		} else {
			System.err.println("Digite uma opção valida!");
		}
	}
	public static void menuAtualizar(Connection conn, Aluno aluno) throws SQLException {
		Scanner s =  new Scanner(System.in);
		int opc =0;
		
		System.out.println("MENU DE ATUALIZÇÃO DE CADASTRO DE ALUNOS ");
		System.out.println("1 - Atualizar celular");
		System.out.println("2 - Atualizar telefone fixo");
		System.out.println("3 - Atualizar email");
		System.out.println("4 - Voltar ao menu principal");
		System.out.println("Digite a opção desejada: ");
		opc = s.nextInt();
		
		switch (opc) {
		
		case 1:
			System.out.println("Digite o cpf do aluno: ");
			String cpf = s.next();
			aluno.setCpf(cpf);
			System.out.println("Digite o novo numero: ");
			String numero = s.next();
			aluno.setCelular(numero);
			
			MetodosSql.atualizarCelular(conn, aluno);
			
			break;
		case 2: 
			System.out.println("Digiite o Cpf do aluno: ");
			 cpf = s.next();
			aluno.setCpf(cpf);
			System.out.println("Digite o novo numero: ");
			 numero = s.next();
			aluno.setTelefone(numero);
			MetodosSql.atualizarTelefone(conn, aluno);
			break;
		case 3:
		System.out.println("Digite o cpf do aluno: ");
		cpf = s.next();
		aluno.setCpf(cpf);
		System.out.println("Digite o novo email do aluno: ");
		String email = s.next();
		aluno.setEmail(email);
		
		MetodosSql.atualizarEmail(conn, aluno);
		break;
		case 4: 
			menu(conn,aluno);
			break;
		default:
			menuAtualizar(conn,aluno);
		break;
		}
		
		
		
	}
	public static void menu(Connection conn, Aluno aluno) throws SQLException {
		Scanner s = new Scanner(System.in);
		Scanner sn = new Scanner(System.in);
		int opc = 0;
		do {

			System.out.println("GERENCIDOR ACADEMICO");
			System.out.println("1 - Cadastar Aluno");
			System.out.println("2 - Excluir");
			System.out.println("3 - Consultar ");
			System.out.println("4 - Atualizar");
			System.out.println("0 - Sair");
			System.out.println("Digite a opção desejada: ");
			opc = sn.nextInt();
			switch (opc) {
			case 1:
				menuCadastro(conn,aluno);
				
				break;
			case 2:
				menuExcluir(conn,aluno);
				break;

			case 3:
				menuConsulta(conn,aluno);
				break;
			case 4:
				menuAtualizar(conn,aluno);
				break;
			}
		} while (opc != 0);

	}
}
