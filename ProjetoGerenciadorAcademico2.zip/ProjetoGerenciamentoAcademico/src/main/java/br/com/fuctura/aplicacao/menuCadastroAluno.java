package br.com.fuctura.aplicacao;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;

import br.com.fuctura.entidades.Aluno;
import br.com.fuctura.metodosSql.MetodosSql;

public class menuCadastroAluno {
public static void cadastrarAluno(Aluno aluno,Scanner s,Connection conn) throws SQLException {
	System.out.println("Digite o nome do aluno: ");
	aluno.setNome(s.nextLine());
	System.out.println("Digite o genero do aluno: ");
	aluno.setGenero(s.next());
	System.out.println("Digite o cpf do aluno: ");
	aluno.setCpf(s.next());
	
	MetodosSql.adicionarAluno(conn, aluno);
}
}
